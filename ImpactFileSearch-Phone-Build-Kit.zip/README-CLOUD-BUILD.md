# Impact File Search: build from an Android phone

This starter package includes a GitHub Actions workflow so you can build the Android APK without installing Android Studio on your phone.

## 1. Create a GitHub repository

1. In your Android browser, sign in at https://github.com.
2. Create a new repository named `ImpactFileSearch`.
3. Choose **Private** unless you intentionally want the source public.
4. Create the repository.

## 2. Upload the two items

At the repository's **Add file > Upload files** page, upload:

- `ImpactFileSearch-Android-Starter.zip`
- `.github/workflows/android.yml`

The workflow file is inside the `.github/workflows/` folder in this package. GitHub's web uploader may not show hidden folders from Android's file picker. If it does not, create the file directly on GitHub:

1. Choose **Add file > Create new file**.
2. Enter `.github/workflows/android.yml` as the filename.
3. Paste the workflow content from the package's `.github/workflows/android.yml` file.
4. Commit the file.

Then upload the ZIP as a separate file.

## 3. Run the build

1. Open the repository's **Actions** tab.
2. Select **Build Impact File Search APK**.
3. Choose **Run workflow** and confirm.
4. Wait for the job to finish successfully.
5. Open the completed workflow run and find **Artifacts**.
6. Download `ImpactFileSearch-debug-apk`.
7. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
8. Open the APK on your Android phone and follow Android's install prompt. Only install APKs you built yourself from your own repository.

## Notes

- This produces a debug APK for testing, not a Play Store release.
- The first build downloads Gradle and Android dependencies and may take several minutes.
- If the build fails, open the failed job, copy the first meaningful error and share it for troubleshooting.
- Network SMB search is not implemented yet. The starter contains the initial app foundation and network integration contract; the APK is an early development build, not the finished network-search product.
