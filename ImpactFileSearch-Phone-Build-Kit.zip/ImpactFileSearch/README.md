# Impact File Search (Android MVP starter)

This is the initial Android Studio project scaffold for Impact File Search.

## Current status
- Native Kotlin + Jetpack Compose application shell.
- Search UI for phone and SMB network locations.
- SMBJ 0.15.0 dependency selected for SMB2/SMB3 integration.
- Data models for saved server profiles, search options, and results.
- Android Storage Access Framework direction documented for user-selected local folders.

**This is not a finished APK.** The server form is currently a UI placeholder, not a live SMB connection. The local folder picker and recursive local search are also not wired into the screen yet. Network credentials are not persisted. Do not enter real credentials into this preview.

## Build
1. Install Android Studio with Android SDK Platform 36 and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync and dependency downloads.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

The debug APK, when built successfully, will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Next implementation milestones
1. Fix and wire the SAF folder picker; implement cancellable recursive local filename search.
2. Implement SMBJ connection adapter (SMB2/3), share browsing, recursive search, timeouts, and cancellation.
3. Store credentials using Android Keystore-backed encryption; never log secrets.
4. Add content extraction for TXT, PDF, DOCX, and XLSX with size limits and an opt-in index.
5. Add Windows companion client only if requested; this MVP target is Android connecting to multiple Windows/NAS SMB servers.

## Security defaults
- Read-only SMB access.
- No inbound server/listener.
- No cloud relay or external exposure of SMB.
- Use a trusted LAN or VPN. Do not expose TCP 445 directly to the public internet.
