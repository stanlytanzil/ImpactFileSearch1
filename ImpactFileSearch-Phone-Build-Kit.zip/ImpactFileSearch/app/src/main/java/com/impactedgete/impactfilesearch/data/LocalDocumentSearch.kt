package com.impactedgete.impactfilesearch.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.impactedgete.impactfilesearch.model.FileHit
import com.impactedgete.impactfilesearch.model.SearchOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.coroutines.coroutineContext

/** Searches only folders explicitly granted by the user through Android's Storage Access Framework. */
class LocalDocumentSearch(private val context: Context) {
    suspend fun search(rootUri: Uri, options: SearchOptions, onHit: (FileHit) -> Unit) = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, rootUri) ?: return@withContext
        walk(root, options, onHit)
    }

    private suspend fun walk(folder: DocumentFile, options: SearchOptions, onHit: (FileHit) -> Unit) {
        for (entry in folder.listFiles()) {
            coroutineContext.ensureActive()
            if (entry.isDirectory) {
                walk(entry, options, onHit)
                continue
            }
            val name = entry.name ?: continue
            val extension = name.substringAfterLast('.', "").lowercase()
            val extFilter = options.extension.trim().removePrefix(".").lowercase()
            if (extFilter.isNotBlank() && extension != extFilter) continue

            val nameMatches = name.contains(options.query, ignoreCase = true)
            val contentMatches = if (!nameMatches && options.contentMode.name == "NAME_AND_CONTENT") {
                containsText(entry.uri, options.query, extension, entry.length())
            } else false

            if (nameMatches || contentMatches) {
                onHit(FileHit(name, entry.uri.toString(), entry.length(), entry.lastModified(), "Phone", entry.uri))
            }
        }
    }

    private fun containsText(uri: Uri, query: String, extension: String, size: Long): Boolean {
        // First MVP supports small plain-text formats. PDF/Office extraction is a later milestone.
        if (extension !in setOf("txt", "md", "csv", "log")) return false
        if (size < 0 || size > MAX_TEXT_BYTES) return false
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input)).useLines { lines ->
                    lines.any { it.contains(query, ignoreCase = true) }
                }
            } ?: false
        } catch (_: Exception) {
            false
        }
    }

    private companion object { const val MAX_TEXT_BYTES = 2L * 1024L * 1024L }
}
