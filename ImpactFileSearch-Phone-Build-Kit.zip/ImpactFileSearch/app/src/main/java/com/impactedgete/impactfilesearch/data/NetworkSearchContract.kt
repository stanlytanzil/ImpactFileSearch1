package com.impactedgete.impactfilesearch.data

import com.impactedgete.impactfilesearch.model.FileHit
import com.impactedgete.impactfilesearch.model.SearchOptions
import com.impactedgete.impactfilesearch.model.ServerProfile

/** Contract for the SMBJ adapter. Implement with SMBJ 0.15.0 in the network milestone. */
interface NetworkSearch {
    suspend fun testConnection(profile: ServerProfile, password: CharArray): Result<Unit>
    suspend fun search(
        profile: ServerProfile,
        password: CharArray,
        options: SearchOptions,
        onHit: suspend (FileHit) -> Unit
    )
}
