package com.impactedgete.impactfilesearch.model

import android.net.Uri

/** A saved network destination. Passwords must be stored separately using Android Keystore. */
data class ServerProfile(
    val id: String,
    val displayName: String,
    val host: String,
    val share: String,
    val domain: String = "",
    val username: String = "",
    val startPath: String = ""
)

enum class SearchLocation { LOCAL, NETWORK, BOTH }
enum class ContentMode { NAME_ONLY, NAME_AND_CONTENT }

data class SearchOptions(
    val query: String,
    val location: SearchLocation = SearchLocation.BOTH,
    val contentMode: ContentMode = ContentMode.NAME_ONLY,
    val extension: String = ""
)

data class FileHit(
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val modifiedMillis: Long,
    val source: String,
    val uri: Uri? = null,
    val isDirectory: Boolean = false
)
