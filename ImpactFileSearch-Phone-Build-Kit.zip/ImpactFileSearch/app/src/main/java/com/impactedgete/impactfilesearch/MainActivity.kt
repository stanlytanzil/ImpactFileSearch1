package com.impactedgete.impactfilesearch

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.impactedgete.impactfilesearch.model.FileHit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ImpactFileSearchApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ImpactFileSearchApp() {
    var query by remember { mutableStateOf("") }
    var extension by remember { mutableStateOf("") }
    var searchContent by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Choose a local folder or add an SMB server to begin.") }
    var results by remember { mutableStateOf(listOf<FileHit>()) }
    var showServerForm by remember { mutableStateOf(false) }
    var host by remember { mutableStateOf("") }
    var share by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF1769AA))) {
        Scaffold(topBar = {
            TopAppBar(title = {
                Column {
                    Text("Impact File Search", fontWeight = FontWeight.Bold)
                    Text("Phone • Windows • NAS", style = MaterialTheme.typography.labelSmall)
                }
            })
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Search file name or text") },
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = extension, onValueChange = { extension = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("File extension (optional, e.g. pdf)") },
                        singleLine = true
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = true, onClick = { }, label = { Text("Phone + Network") })
                        FilterChip(selected = searchContent, onClick = { searchContent = !searchContent }, label = { Text("Search contents") })
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { status = "Local folder picker and search are being connected in the next build." }, modifier = Modifier.weight(1f)) {
                            Text("Choose folder")
                        }
                        OutlinedButton(onClick = { showServerForm = !showServerForm }, modifier = Modifier.weight(1f)) {
                            Text("Add server")
                        }
                    }
                }
                if (showServerForm) {
                    item {
                        Card(shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("SMB network connection", fontWeight = FontWeight.Bold)
                                OutlinedTextField(host, { host = it }, Modifier.fillMaxWidth(), label = { Text("Server IP or hostname") }, singleLine = true)
                                OutlinedTextField(share, { share = it }, Modifier.fillMaxWidth(), label = { Text("Share name") }, singleLine = true)
                                OutlinedTextField(username, { username = it }, Modifier.fillMaxWidth(), label = { Text("Username (optional for guest shares)") }, singleLine = true)
                                Text("Credentials are not saved in this preview. Secure credential storage and SMB connection testing are next.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Button(onClick = { status = if (host.isBlank() || share.isBlank()) "Enter a server and share name." else "Connection profile form captured. SMB connection test is the next milestone." }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Save connection")
                                }
                            }
                        }
                    }
                }
                item {
                    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Search status", fontWeight = FontWeight.SemiBold)
                            Text(status, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                item { Text("Search results (${results.size})", fontWeight = FontWeight.Bold) }
                if (results.isEmpty()) {
                    item { Text("No results yet. Connect a folder or network share to start searching.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                } else {
                    items(results) { hit ->
                        ListItem(
                            headlineContent = { Text(hit.name) },
                            supportingContent = { Text(hit.path) },
                            overlineContent = { Text(hit.source) }
                        )
                        HorizontalDivider()
                    }
                }
                item {
                    Text("MVP build 0.1.0 • Read-only search design", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
